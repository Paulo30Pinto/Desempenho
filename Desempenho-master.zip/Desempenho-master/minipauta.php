<div class="card-body table-responsive">
<form class="table-responsive" action="conexao/pdo_cadastro.php" method="post" id="notapauta">
<h1>
    <?=$idTurma?>
  </h1>
    <h5 class="card-title">Mini Pauta Aluno</h5>
    <div class="row py-3">

                     <!--<div class="card-footer text-muted text-center" id="detroturma">
                    <a href="#detroturma" class="btn btn-azul" 
                          style="position: fixed;bottom: 50px; right: 50px;">Guardar</a>
                    </div>-->

                      <div class="card-footer text-muted text-center">
                        <a href="#detroturma" class="btn btn-azul">Guardar a Mini pauta</a>
                      </div>
                      <div class="col-6">
                        <label for="firstName" class="form-label">Disciplina</label>
                        <?php
                              $professor_id = $idProf;
                              
                           $sqldisciplinas = "SELECT disciplinas.id_disciplina, disciplinas.nome AS disciplina_nome, turmas.nome AS turma_nome, classes.nome AS classe_nome, cursos.nome AS curso_nome FROM professores JOIN professor_disciplina ON professores.id_professor = professor_disciplina.professor_id JOIN disciplinas ON professor_disciplina.disciplina_id = disciplinas.id_disciplina JOIN cursos ON disciplinas.curso_id = cursos.id_curso  JOIN turma_disciplina ON disciplinas.id_disciplina = turma_disciplina.disciplina_id JOIN turmas ON turma_disciplina.turma_id = turmas.id_turma JOIN classes ON turmas.classe_id = classes.id_classe WHERE professores.id_professor = ?";
 
                           $stmt01 = $conexao->prepare($sqldisciplinas);
                           $stmt01->bind_param("i", $professor_id);
                           $stmt01->execute();
                           $result01 = $stmt01->get_result(); 
                           
                     //     $resultado = mysqli_query($conexao, $sqldisciplinas);
                          // $result = $conexao->query($sqldisciplinas);

                        ?>

<?php
                          if ($result01->num_rows > 0) {
                            $counter = 1;
                          echo  "<select class='form-select' aria-label='Default select example' name='discnone' id='discnone'>";
                          echo  "<option selected>Escolha uma disciplina</option>";
                            while($row = $result01->fetch_assoc()) {
                              echo "<option value=". htmlspecialchars($row['id_disciplina']) .">
                                  ". htmlspecialchars($row['disciplina_nome']) ."
                              </option>";
                               
                                $counter++;
                            }
                          echo "</select>";
                        } else {
                            echo "<tr><td colspan='5'>Nenhuma disciplina encontrada</td></tr>";
                        }
                        
                          ?>
                      </div>
                      
                      <div class="col-12 d-flex my-2 justify-content-end">
                            <button class='btn btn-primary mx-2' type="button">
                              <i class='bi bi-printer'></i>
                            </button>
                          <span class="btn btn-info text-white" id="adNota">Add</span>
                      </div>
                    </div>
                    <!-- Small tables -->

                    <table class="table table-sm table-hover table-bordered" >
                     <thead class="" style="">
                            <tr class="text-center">
                              <th rowspan="2" scope="col" style="min-width: 150px;" class="text-center py-4">Nome</th>
                              <th colspan="6" scope="col" class="primeiro">Iº Trimestre</th>
                              <th colspan="6" scope="col" class="segundo">IIº Trimestre</th>
                              <th colspan="6" scope="col" class="terceiro">IIIº Trimestre</th>
                              <th rowspan="2" scope="col" class="final">MFD</th>
                            </tr>
                            <tr class="text-center">
                              <td class="nota primeiro">MAC</td>
                              <td class="nota primeiro">NPP</td>
                              <td class="nota primeiro">NPT</td>
                              <td class="nota tab primeiro">MT</td>
                              <td class="nota primeiro">PRE</td>
                              <td class="nota primeiro">PON</td>
                              <td class="nota">MAC</td>
                              <td class="nota">NPP</td>
                              <td class="nota">NPT</td>
                              <td class="nota tab">MT</td>
                              <td class="nota">PRE</td>
                              <td class="nota">PON</td>
                              <td class="nota">MAC</td>
                              <td class="nota">NPP</td>
                              <td class="nota">NPT</td>
                              <td class="nota tab">MT</td>
                              <td class="nota">PRE</td>
                              <td class="nota">PON</td>
                          </tr>
                      </thead>
                      <tbody class="nota-base" >
                      <?php

      $professor_id1 = $idProf; // exemplo estático, substitua conforme necessário
    // echo $professor_id;
 
      // SQL para buscar alunos de uma determinada turma associada ao professor
        $sqlAluno = "SELECT alunos.id_aluno, alunos.nome AS aluno_nome FROM alunos
        JOIN aluno_turma ON alunos.id_aluno = aluno_turma.aluno_id
          JOIN turmas ON aluno_turma.turma_id = turmas.id_turma 
          JOIN turma_disciplina ON turmas.id_turma = turma_disciplina.turma_id
            JOIN disciplinas ON turma_disciplina.disciplina_id = disciplinas.id_disciplina
  JOIN professor_disciplina ON disciplinas.id_disciplina = professor_disciplina.disciplina_id
  WHERE professor_disciplina.professor_id = ? GROUP BY aluno_turma.aluno_id";

  $stmt1 = $conexao->prepare($sqlAluno);
  $stmt1->bind_param("i", $professor_id1);
  $stmt1->execute();
  $result1 = $stmt1->get_result();

  //print_r($result1);

            if ($result1->num_rows > 0) {
              $counter1 = 1;
              while($row1 = $result1->fetch_assoc()) {
                    ?>
                              <tr>
                                <td class="displina"><b><?=$counter1++;?></b> <?php echo $row1['aluno_nome']; ?> 
                                <input type="hidden" name="notaAluno<?=$counter1;?>" id="notaAluno<?=$counter1;?>" value="<?php echo $row1['id_aluno']; ?>">
                                <input type="hidden" name="notaProfe<?=$counter1;?>" id="<?=$counter1;?>" value="<?=$professor_id1;?>">
                                <input type="hidden" name="notaidCurso<?=$counter1;?>" id="notaidCurso<?=$counter1;?>" value="<?=$idCurso;?>">
                                <input type="hidden" name="notaidClasse<?=$counter1;?>" id="notaidClasse<?=$counter1;?>" value="<?=$idClasse;?>">

                            </td>
                                <td class="primeiro">
                                  <input type="text" class="form-control" readOnly id="mac1<?=$counter1;?>" name="mac1<?=$counter1;?>" placeholder="0" >
                                </td>
                                <td class="primeiro">
                                <input type="text" class="form-control" id="NPP1<?=$counter1;?>" name="NPP1<?=$counter1;?>" placeholder="0" readOnly>
                                </td>
                                <td class="primeiro">
                              <input type="text" class="form-control" id="NPT1<?=$counter1;?>" name="NPT1<?=$counter1;?>" placeholder="0" disabled >
                              </td>
                              <td class="tab primeiro">Media <input type="hidden" name="<?=$counter1;?>" id="mediaponto1<?=$counter1;?>"></td>
                              <td class="primeiro">
                              <input type="text" class="form-control" id="PRE1<?=$counter1;?>" name="PRE1<?=$counter1;?>" placeholder="0" disabled>
                              </td>
                              <td class="primeiro">
                              <input type="text" class="form-control" id="PON1<?=$counter1;?>" name="PON1<?=$counter1;?>" placeholder="0" disabled>
                              </td>
                              <td>
                              <input type="text" class="form-control" id="mac2" name="mac2" placeholder="0" disabled>
                              </td>
                              <td>
                              <input type="text" class="form-control" id="NPP2" name="NPP2" placeholder="0" disabled>
                              </td>
                              <td>
                              <input type="text" class="form-control" id="NPT2" name="NPT2" placeholder="0" disabled>
                              </td>
                              <td class="tab">Media <input type="hidden" name="mediaponto2" id="mediaponto2"></td>
                              <td>
                              <input type="text" class="form-control" id="PRE2" name="PRE2" placeholder="0" disabled>
                              </td>
                              <td>
                              <input type="text" class="form-control" id="PON2" name="PON2" placeholder="0" disabled>
                              </td>
                              <td>
                                <input type="text" class="form-control" id="mac3" name="mac3" placeholder="0" disabled>
                              </td>
                              <td>
                                <input type="text" class="form-control" id="NPP3" name="NPP3" placeholder="0" disabled>
                              </td>
                              <td>
                                <input type="text" class="form-control" id="NPT3" name="NPT3" placeholder="0" disabled>
                              </td>
                              <td class="tab">Media <input type="hidden" name="mediaponto3" id="mediaponto3"></td>
                              <td>
                                <input type="text" class="form-control" id="PRE3" name="PRE3" placeholder="0" disabled>
                              </td>
                              <td>
                                <input type="text" class="form-control" id="PON3" name="PON3" placeholder="0" disabled>
                              </td>
                              <td>Final</td>
                          </tr>
                         
              <?php            
                }
              }
                ?>
                      </tbody>
                    </table>

                    <button class="w-100 btn btn-info btn-lg" type="submit" name="guardProva" id="guardProva" >Guardar</button>
                    </form>
                    <!-- End small tables -->
  </div>

<script>
  
</script>