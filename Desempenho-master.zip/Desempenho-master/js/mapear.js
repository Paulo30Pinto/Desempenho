$(function(){
	//alert("ola mundo!");
	$("#btn-menu").click(function(){
		$("#sidebarMenu").toggleClass("lateralmenu");
	})
})