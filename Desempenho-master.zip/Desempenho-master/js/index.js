
$(document).ready(function() {
    // body...
    $("a[href='#inicio']").click(()=>{
    /*   // alert("Ola")
       $("#page-inicio").removeClass('d-none')
       $("#pg-aula").addClass('d-none') */
    })

    $("a[href='#detroturma']").click(()=>{
       // alert("Ola")
     /*  $("#page-inicio").addClass('d-none')
       $("#pg-aula").removeClass('d-none') */
    })

    $('#dropdownNavLink').click(function(){
        $('#tel').toggleClass("tel");
    })
})