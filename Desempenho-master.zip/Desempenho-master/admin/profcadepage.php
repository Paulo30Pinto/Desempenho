 <!-- MODAL CADASTRO  DO PROFESSOR-->
 <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 d-none" id="cadProf">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Cadastrar Professor</h1>
        <div class="btn-toolbar mb-2 mb-md-0" hidden>
          <div class="btn-group me-2">
            <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
            <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
          </div>
          <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
            <span data-feather="calendar"></span>
            This week
          </button>
        </div>
      </div>
      <div class="container">
        <form action="conexao/pdo_cadastro.php" method="post" enctype="multipart/form-data" class="needs-validation"  novalidate>
          <div class="row g-3">
            <div class="col-sm-6">
              <label for="firstName" class="form-label">insira o nome completo</label>
              <input type="text" class="form-control" id="nomeProf" name="nomeProf" placeholder="nome" value="" required>
              <div class="invalid-feedback">
                não insiriu o seu nome.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="state" class="form-label">número do BI</label>
              <input type="text" class="form-control" id="num_BIProfe" name="num_BIProfe" placeholder="nome da escola">
              <div class="invalid-feedback">
                Please provide a valid state.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="state" class="form-label">Morada</label>
              <input type="text" class="form-control" id="moradaprof" name="moradaprof" placeholder="nome da escola">
              <div class="invalid-feedback">
                Please provide a valid state.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="lastName" class="form-label">Telefone</label>
              <input type="text" class="form-control" id="telefoneProfe" name="telefoneProfe" placeholder="contato" value="">
              <div class="invalid-feedback">
                não insiriu o seu contato.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="email" class="form-label">email</label>
              <div class="input-group has-validation">
                <span class="input-group-text">@</span>
                <input type="email" class="form-control" id="emailProf" name="emailProf" placeholder="email" >
              <div class="invalid-feedback">
                não insiriu o seu email.
                </div>
              </div>
            </div>

            <div class="col-sm-6">
              <label for="username" class="form-label">insira a senha</span></label>
              <input type="text" class="form-control" id="senhaProf" name="senhaProf" placeholder="senha" >
              <div class="invalid-feedback">
                não insiriu a senha.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="address" class="form-label">senha de confirmação</label>
              <input type="text" class="form-control" id="confSenhaProf" name="confSenhaProf" placeholder="senha confirmção">
              <div class="invalid-feedback">
                não confirmou a senha.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="zip" class="form-label">foto de perfil<span class="text-muted">(Optional)</span></label>
              <input type="file" class="form-control" id="fotoPprof"  name="fotoProf" value="" placeholder="foto" >
              <div class="invalid-feedback">
                Zip code required.
              </div>
            </div>
            <div class="col-sm-6">
                <h4 class="mb-3">Sexo</h4>
              <div class="my-3 d-flex justify-content-around aling-items-center">
                <div class="form-check">
                  <input id="sexoMascProf" name="sexoProf" type="radio" class="form-check-input" value="Masculino" checked >
                  <label class="form-check-label" for="credit">Masculino</label>
                </div>
                <div class="form-check">
                  <input id="sexoFemProf" name="sexoProf" type="radio" class="form-check-input" value="Feminino" >
                  <label class="form-check-label" for="debit">Feminino</label>
                </div>
                <div class="form-check">
                  <input id="sexoOutrocProf" name="sexoProf" type="radio" class="form-check-input" value="Outros" >
                  <label class="form-check-label" for="paypal">Outros</label>
                </div>
              </div>
            </div>
          </div>
          <hr class="my-4">
          <button class="w-100 btn btn-primary btn-lg" type="submit" name="cadProfe" id="cadProfe">cadastra-se</button>
        </form>
      </div>
    </main>