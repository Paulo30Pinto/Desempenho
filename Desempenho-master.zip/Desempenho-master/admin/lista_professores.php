  <!-- LISTAS DE PROFESSORES CADASTRADOS  -->

  <h2>Lista de Professores Cadastrados</h2>
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">image</th>
              <th scope="col">Nome</th>
              <th scope="col">Turma</th>
              <th scope="col">Disciplina</th>
              <th scope="col">Accoes</th>
            </tr>
          </thead>
          <tbody>
            <?php
                $contador = 0;
              // $selecionaProf = $conexao->query("SELECT * FROM professores");
              $selecionaProf = $conexao->query("SELECT *, cs.nome AS curso, tm.nome AS turma, cl.nome AS classe, p.nome as professores FROM turma_disciplina td INNER JOIN professores p ON td.id_professor_turma = p.id_professor INNER JOIN cursos cs ON td.id_curso_turma = cs.id_curso INNER JOIN turmas tm ON td.turma_id = tm.id_turma INNER JOIN classes cl ON tm.classe_id = cl.id_classe GROUP BY p.id_professor");

              while($prof = $selecionaProf->fetch_assoc()){ 
                $contador++;
                 echo '<tr>';
                 echo "<td>$contador</td>";
                 echo "<td><img class='bi me-2 pic' width='40' height='32' src='../img/$prof[foto_prof]' /></td>";
                 echo '<td>'. $prof['professores']. '</td>';
                 echo '<td>'. $prof['turma']. '</td>';
                 echo '<td>'. $prof['curso']. '</td>';
                 echo "<td class='d-flex'><a class='btn btn-primary' href='profesTurmas.php'>
                    <i class='bi bi-eye'></i>
                 </a> <a class='btn btn-success mx-1' href='profesTurmas.php'>
                  <i class='bi bi-pencil'></i>
                 </a> <a class='btn btn-danger' href='profesTurmas.php'><i class='bi bi-trash'></i></a></td>";
                 echo '</tr>';
               }  
              
              /*
               while($prof = $selecionaProf->fetch_assoc()){
                $contador++;
                 echo '<tr>';
                 echo "<td>$contador</td>";
                 echo "<td><img class='bi me-2 pic' width='40' height='32' src='../img/$prof[foto_prof]' /></td>";
                 echo '<td>'. $prof['nome']. '</td>';
                 echo '<td>'. $prof['email']. '</td>';
                 echo '<td>'. $prof['contacto_professor']. '</td>';
                 echo "<td><a href='profesTurmas.php'>Editar</a></td>";
                 echo '</tr>';
               }
                 */
            ?>
          </tbody>
        </table>
      </div>