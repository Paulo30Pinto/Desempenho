<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Signin Template · Bootstrap v5.1</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/sign-in/">

    

    <!-- Bootstrap core CSS -->
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

    </style>

    
    <!-- Custom styles for this template -->
    <link href="../css/signin.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/form-validation.css">
  </head>
  <body class="text-center" style="">
    
<main class="form-signin" id="form-signin">
  <form>
    <img class="mb-4" src="../img/a7.png" alt="" width="72" height="57">
    <h1 class="h3 mb-3 fw-normal">faça login</h1>

    <div class="form-floating">
      <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
      <label for="floatingInput">Email ou número</label>
    </div>
    <div class="form-floating">
      <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
      <label for="floatingPassword">insira a senha</label>
    </div>

    <div class="checkbox mb-3">
      <label hidden>
        <input type="checkbox" value="remember-me"> Remember me
      </label>
    </div>
    <a class="w-100 btn btn-lg btn-primary" href="app.php">logar</a>
    <p class="mt-5 mb-3 text-muted"><a href="#novocadastro" id="chamaCad">cadastra-se</a></p>
  </form>
</main>

<main class="container d-none text-white" id="novocadastro" style="padding-top: 0em !important;">
    <a href="#" id="voltalogin" class="text-start float-start">login</a>
    <div class="py-5 text-center">
      <img class="d-block mx-auto mb-4" src="../img/a22.png" alt="" width="72" height="57">
      <h2>informações gerais</h2>
      <p class="lead">faça o cadastro de acordo com a escola onde trabalha, para ajudar a identificação das turmas</p>
    </div>

    <div class="row g-5">
      
      <div class="col-md-12 col-lg-12">
       
        <form class="needs-validation" novalidate>
          <div class="row g-3">
            <div class="col-sm-6">
              <label for="firstName" class="form-label">insira o seu 1º e último nome</label>
              <input type="text" class="form-control" id="firstName" placeholder="nome" value="" required>
              <div class="invalid-feedback">
                não insiriu o seu nome.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="lastName" class="form-label">contato</label>
              <input type="text" class="form-control" id="lastName" placeholder="contato" value="" required>
              <div class="invalid-feedback">
                não insiriu o seu contato.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="email" class="form-label">email</label>
              <div class="input-group has-validation">
                <span class="input-group-text">@</span>
                <input type="email" class="form-control" id="email" placeholder="email" required>
              <div class="invalid-feedback">
                não insiriu o seu email.
                </div>
              </div>
            </div>

            <div class="col-sm-6">
              <label for="username" class="form-label">insira a senha</span></label>
              <input type="text" class="form-control" id="username" placeholder="senha"required>
              <div class="invalid-feedback">
                não insiriu a senha.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="address" class="form-label">senha de confirmação</label>
              <input type="text" class="form-control" id="address" placeholder="senha confirmção" required>
              <div class="invalid-feedback">
                não confirmou a senha.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="address2" class="form-label"> nome da escola onde trabalha</label>
              <input type="text" class="form-control" id="address2" placeholder="nome da escola"required>
            </div>

            <div class="col-sm-6">
              <label for="country" class="form-label">localidade da escola </label>
              <select class="form-select" id="country" required>
                <option value="">luanda/kilamba kiaxi</option>
                <option>Luanda/viana</option>
                <option>Luanda/cazenga</option>
              </select>
              <div class="invalid-feedback">
                Please select a valid country.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="state" class="form-label">número da escola</label>
              <input type="text" class="form-control" id="address2" placeholder="nome da escola">
              <div class="invalid-feedback">
                Please provide a valid state.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="zip" class="form-label">foto de perfil<span class="text-muted">(Optional)</span></label>
              <input type="file" class="form-control" id="zip" placeholder="foto" required>
              <div class="invalid-feedback">
                Zip code required.
              </div>
            </div>
            <div class="col-sm-6">
                <h4 class="mb-3">Sexo</h4>
              <div class="my-3 d-flex justify-content-around aling-items-center">
                <div class="form-check">
                  <input id="credit" name="paymentMethod" type="radio" class="form-check-input" checked required>
                  <label class="form-check-label" for="credit">Masculino</label>
                </div>
                <div class="form-check">
                  <input id="debit" name="paymentMethod" type="radio" class="form-check-input" required>
                  <label class="form-check-label" for="debit">Feminino</label>
                </div>
                <div class="form-check">
                  <input id="paypal" name="paymentMethod" type="radio" class="form-check-input" required>
                  <label class="form-check-label" for="paypal">Outros</label>
                </div>
              </div>
            </div>
           
            
          </div>
          
          <hr class="my-4">

          <button class="w-100 btn btn-primary btn-lg" type="submit" href="app.php">cadastra-se</button>
        </form>
      </div>
    </div>
  </main>



    
  </body>
  <script src="../js/jquery-3.5.1.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../js/form-validation.js"></script>

  <script>
    $("#chamaCad").click(()=>{
       // alert("Ola")
       $("#form-signin").addClass("d-none")
       $("#novocadastro").removeClass("d-none")
    })
    $("#voltalogin").click(()=>{
       // alert("Ola")
       $("#form-signin").removeClass("d-none")
       $("#novocadastro").addClass("d-none")
    })
  </script>

</html>
