<?php
include_once "pdo_conexao.php";
include_once "sqli_conexao.php";

//Conexão aula cadastro
if (isset($_POST['cadProfe'])) {

  $fotoProf = $_FILES["fotoProf"];

  move_uploaded_file($fotoProf["tmp_name"], "../../img/professores/".$fotoProf["name"]);
  $novoNome = $fotoProf["name"];

  $nomeProf = $_POST['nomeProf'];
  $emailProf = $_POST['emailProf'];
  $senhaProf = $_POST['senhaProf'];
  $num_BIProfe = $_POST['num_BIProfe'];
  $moradaprof = $_POST['moradaprof'];
  $telefoneProfe = $_POST['telefoneProfe'];
  $sexoProf = $_POST['sexoProf'];

 $sql = "INSERT INTO professores (nome, email, senha, foto_prof, contacto_professor, sexo) VALUES ('$nomeProf', '$emailProf', '$senhaProf', '$novoNome', '$telefoneProfe', '$sexoProf')";


    if(mysqli_query($conexao, $sql)){
      //	$_SESSION['mensagem'] = "Cadastrado com sucesso";
    //  header('Location: servico.php?sucesso');
     	  echo "<script>alert('Cadastrado com sucesso')
              window.location = '../app.php?sucesso'
        </script>"; 
        //echo "certo";
    }
   
    else{
      //	$_SESSION['mensagem'] = "Erro de cadastro";
     // header('Location: servico.php?Error');
      	  echo "<script>alert('Erro ao cadastrar')
          window.location = '../app.php?erro'
              </script>"; 
            //  echo "Erro;";
    }


}

if (isset($_POST['cadaluno'])) {
  echo "dados do aluno";
  $nomealuno = $_POST['nomeAluno'];
  $aluno_bi  = $_POST['bialuno'];
  $Contacto  = $_POST['contacoaluno'];
  $genero  = $_POST["sexo"];
  $aluno_curso  = $_POST['cursonome'];
  $aluno_classe  = $_POST['classe'];
  $aluno_turma = $_POST['turmanome'];

  $sql = "INSERT INTO alunos (nome, Contacto, aluno_bi, genero, aluno_curso, aluno_classe, aluno_turma) VALUES ('$nomealuno', '$Contacto', '$aluno_bi', '$genero', '$aluno_curso', '$aluno_classe', '$aluno_turma')";

  if(mysqli_query($conexao, $sql)){

    $pergarAluno = "SELECT * FROM alunos WHERE aluno_bi = '$aluno_bi'";
    $resultado = mysqli_query($conexao, $pergarAluno);
    $dados = mysqli_fetch_array($resultado);
    $idAluno = $dados['id_aluno'];

    /*
      MAC	int(11)			Sim	NULL			Muda Muda	Eliminar Eliminar	
	3	NPP	int(11)			Sim	NULL			Muda Muda	Eliminar Eliminar	
	4	NPT	int(11)			Sim	NULL			Muda Muda	Eliminar Eliminar	
	5	MT	int(11)			Sim	NULL			Muda Muda	Eliminar Eliminar	
	6	PRE	int(11)			Sim	NULL			Muda Muda	Eliminar Eliminar	
	7	PON	int(11)			Sim	NULL			Muda Muda	Eliminar Eliminar	
	8	MFD	int(11)			Sim	NULL			Muda Muda	Eliminar Eliminar	
	9	trimestre	tinyint(4)			Sim	NULL			Muda Muda	Eliminar Eliminar	
	10	id_professor Índice	int(11)			Não	Nenhum			Muda Muda	Eliminar Eliminar	
	11	id_aluno Índice	int(11)			Não	Nenhum			Muda Muda	Eliminar Eliminar	
	12	id_classe Índice	int(11)			Não	Nenhum			Muda Muda	Eliminar Eliminar	
	13	id_curso Índice	int(11)			Não	Nenhum			Muda Muda	Eliminar Eliminar	
	14	id_desciplina Índice

    */

    $minipautaAluno = "INSERT INTO tb_notas (MAC, id_aluno) VALUES (0, $idAluno)";  
    
    //	$_SESSION['mensagem'] = "Cadastrado com sucesso";
  //  header('Location: servico.php?sucesso');
 	  echo "<script>alert('Cadastrado com sucesso')
            window.location = '../app.php?sucesso'
      </script>"; 
     
  }
  else{
    //	$_SESSION['mensagem'] = "Erro de cadastro";
   // header('Location: servico.php?Error');
  	  echo "<script>alert('Erro ao cadastrar')
        window.location = '../app.php?erro'
            </script>"; 
           // echo "Erro;";
  }
}

if (isset($_POST['btnCusro'])) {
 // echo "dados do aluno";
  $nomealuno = $_POST['cursonome'];
  $classe = $_POST['classe'];
  $disciplina = $_POST['disciplina'];

  echo "dados do aluno ".$nomealuno;
  

  $sql = "INSERT INTO curso_disciplina (id_disciplina, id_classe, id_curso) VALUES ('$nomealuno', '$classe', '$disciplina')";
  if(mysqli_query($conexao, $sql)){
    //	$_SESSION['mensagem'] = "Cadastrado com sucesso";
  //  header('Location: servico.php?sucesso');
  /* 	  echo "<script>alert('Cadastrado com sucesso')
            window.location = '../aulasgravadas.php?sucesso'
      </script>"; */
      echo "certo";
  }
  else{
    //	$_SESSION['mensagem'] = "Erro de cadastro";
   // header('Location: servico.php?Error');
    /*	  echo "<script>alert('Erro ao cadastrar')
        window.location = '../aulasgravadas.php?erro'
            </script>"; */
            echo "Erro;";
  }
}

if (isset($_POST['btnCadTurma'])) {
  # code...
  
  $turmatitulo = $_POST['turmatitulo'];
  $sala = $_POST['sala'];
  $turno = $_POST['turno'];
  $curso = $_POST['curso'];
  $classe = $_POST['classe'];

  echo "dados do aluno ".$classe;
 
}
if (isset($_POST['cadTurmapf'])) {
  # code...
  $nomeProfe = $_POST['nomeprofe'];
  $classe = $_POST['classe'];
  $cursonome = $_POST['cursonome']; 
  $disciplina = $_POST['disciplina'];
  $turmanome = $_POST['turmanome'];

  echo "dados do aluno ".$nomeProfe;
  
  $sql = "INSERT INTO turma_disciplina (id_professor_turma, turma_id,  	disciplina_id, id_curso_turma, classe_id) VALUES ('$nomeProfe', '$turmanome', '$disciplina', '$cursonome', '$classe')";

  if(mysqli_query($conexao, $sql)){
    //  $_SESSION['mensagem'] = "Cadastrado com sucesso";
    //  header('Location: servico.php?sucesso');
    echo "<script>alert('Cadastrado com sucesso')
          window.location = '../app.php?sucesso'
      </script>";
      //echo "certo";
      }
  else{
    //  $_SESSION['mensagem'] = "Erro de cadastro";
    //  header('Location: servico.php?Error');
    echo "<script>alert('Erro ao cadastrar')
        window.location = '../app.php?erro'
            </script>";
            //echo "Erro;";
  }
     
  
   
 

}

  

?>