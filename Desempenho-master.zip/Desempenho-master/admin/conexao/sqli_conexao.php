<?php
$conexao = mysqli_connect('localhost','root','','controle_bd');
mysqli_set_charset($conexao, "utf8");

?>