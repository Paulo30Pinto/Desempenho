<?php

$dsn	=	'mysql:dbname=controle_bd;host=127.0.0.1';
$usuario	=	'root';
$senha	=	'';
$pdo	=	new	\PDO($dsn,	$usuario,	$senha);

  //  echo "Sem Erro";
?>