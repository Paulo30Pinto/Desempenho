<!-- GERENCIAR TURMAS -->
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 d-none" id="gerenciamento">
      <div class="container py-4">
        <div class="table-responsive">
          <table class="table table-striped table-sm">
            <thead>
              <tr>
                <th scope="col">Número</th>
                <th scope="col">Curso</th>
                <th scope="col">Sala </th>
                <th scope="col">Nome da turma</th>
                <th scope="col">Turno</th>
              </tr>
            </thead>
            <tbody>
                <?php
                    $sql = "SELECT turma_disciplina.id_turma_disciplina, cursos.nome AS curso, professores.nome AS professor, classes.nome AS classar, disciplinas.nome AS disciplina, turmas.nome AS turmar FROM turma_disciplina INNER JOIN cursos ON turma_disciplina.id_curso_turma = cursos.id_curso INNER JOIN professores ON turma_disciplina.id_professor_turma = professores.id_professor INNER JOIN classes ON turma_disciplina.classe_id = classes.id_classe INNER JOIN disciplinas ON turma_disciplina.disciplina_id = disciplinas.id_disciplina INNER JOIN turmas ON turma_disciplina.turma_id = turmas.id_turma";
                    $result = $conexao->query($sql);
                    if ($result->num_rows > 0) {
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                            echo "
                            <tr>
                            <td>$row[id_turma_disciplina]</td>
                            <td>$row[curso]</td>
                            <td>$row[professor]</td>
                            <td>$row[disciplina]</td>
                            <td>$row[classar]</td>
                            </tr>
                            ";
                        }
                    } else {
                        echo "0 results";
                    }
                ?>
              <tr>
                <td>1,015</td>
                <td>random</td>
                <td>tabular</td>
                <td>information</td>
                <td>text</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </main>