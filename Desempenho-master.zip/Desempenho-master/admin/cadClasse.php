  <!--MODAL CADASTRO CURSOS-->
  <div class="modal fade" id="modaCurso" tabindex="-1" aria-labelledby="exampleModalCenteredScrollableTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenteredScrollableTitle">Cadastrar Curso</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="conexao/pdo_cadastro.php" method="post" id="formCurso" class="needs-validation" novalidate>
            <div class="row g-3">
              <div class="col-sm-6">
                <label for="nomeCurso" class="form-label">Nome Do Curso</label>
                <select class="form-select" aria-label="Default select example" name='cursonome' id='cursonome'>
                <option selected >Selecionar Cursos</option>
                  <?php
                    
                    $sqlcurso = "SELECT * FROM cursos";
                    $resultcurso = $conexao->query($sqlcurso);

                    while($rowcurso = $resultcurso->fetch_assoc()) {
                      echo "<option value='$rowcurso[id_curso]'>". $rowcurso["nome"]. "</option>";
                    }
                  
                  ?>
                            
                          
                            
                </select>
              </div>
              <div class="col-sm-6">
                <label for="classeCurso" class="form-label">Classe</label>
                <select class="form-select" aria-label="Default select example" name="classe" id="classe">
                            <option selected>Selecionar Classes</option>
                           
                            <?php
                    
                    $sqlcurso = "SELECT * FROM classes";
                    $resultcurso = $conexao->query($sqlcurso);

                    while($rowcurso = $resultcurso->fetch_assoc()) {
                      echo "<option value='". $rowcurso["id_classe"]. "'>". $rowcurso["nome"]. "</option>";
                    }
                  
                  ?>

                </select>
              </div>
              <div class="col-sm-6">
                <label for="classeCurso" class="form-label">Disciplina</label>
                <select class="form-select" aria-label="Default select example" name="disciplina" id="disciplina">
                            <option selected>Selecionar Disciplina</option>
                           
                            <?php
                    
                    $sqlcurso = "SELECT * FROM disciplinas";
                    $resultcurso = $conexao->query($sqlcurso);

                    while($rowcurso = $resultcurso->fetch_assoc()) {
                      echo "<option value='". $rowcurso["id_disciplina"]. "'>". $rowcurso["nome"]. "</option>";
                    }
                  
                  ?>

                </select>
              </div>
            </div>
            <hr class="my-4">
            <button class="w-100 btn btn-primary btn-lg" type="submit" id="btnCusro" name="btnCusro">Cadastrar</button>
          </form>
        </div>
      </div>
    </div>
  </div>