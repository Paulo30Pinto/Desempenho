<?php
  require_once "conexao/pdo_conexao.php";
  require_once "conexao/sqli_conexao.php";
?>
  <!--MODAL CADASTRO ALUNOS-->
  <div class="modal fade" id="modaluno" tabindex="-1" aria-labelledby="exampleModalCenteredScrollableTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenteredScrollableTitle">Cadastrar Aluno</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="conexao/pdo_cadastro.php" method="post" enctype="multipart/form-data" class="needs-validation"  novalidate>
            <div class="row g-3">
              <div class="col-sm-6">
                <label for="nomeAluno" class="form-label">Nome completo</label>
                <input type="text" class="form-control" id="nomeAluno" name="nomeAluno" placeholder="nome" value="" required>
                <div class="invalid-feedback">
                  não insiriu o seu nome.
                </div>
              </div>

              <div class="col-sm-6">
                <label for="bialuno" class="form-label">número do BI</label>
                <input type="text" class="form-control" id="bialuno" name="bialuno" placeholder="bi" value="" >
                <div class="invalid-feedback">
                  não insiriu o seu número do BI.
                </div>
              </div>

              <div class="col-sm-6">
                <label for="contacoaluno" class="form-label">Contato</label>
                <input type="text" class="form-control" name="contacoaluno" id="contacoaluno" placeholder="contato" value="" >
                <div class="invalid-feedback">
                  não insiriu o seu contato.
                </div>
              </div>

              <div class="col-sm-6">
                <label for="cursoaluno" class="form-label">Cursos</label>

                <select class="form-select" aria-label="Default select example" name='cursonome' id='cursonome'>
                <option selected >Selecionar Cursos</option>
                  <?php
                    
                    $sqlcurso = "SELECT * FROM cursos";
                    $resultcurso = $conexao->query($sqlcurso);

                    while($rowcurso = $resultcurso->fetch_assoc()) {
                      echo "<option value='$rowcurso[id_curso]'>". $rowcurso["nome"]. "</option>";
                    }
                  
                  ?>
                  </select>
              </div>

              <div class="col-sm-6">
                  <label for="turmaaluno" class="form-label">Turma</label>
                  <select class="form-select" aria-label="Default select example"  name='turmanome' id='turmanome'>
                  <option selected >Selecionar Turma</option>
                  <?php
                    
                    $sqlcurso = "SELECT * FROM turmas";
                    $resultcurso = $conexao->query($sqlcurso);

                    while($rowcurso = $resultcurso->fetch_assoc()) {
                      echo "<option value='$rowcurso[id_turma]'>". $rowcurso["nome"]. "</option>";
                    }
                  
                  ?>
                    </select>
              </div>

              <div class="col-sm-6">
                <label for="clasealuno" class="form-label">Classe</span></label>
                <select class="form-select" aria-label="Default select example" name="classe" id="classe">
                <option selected>Selecionar Classes</option>
                           
                           <?php
                   
                   $sqlcurso = "SELECT * FROM classes";
                   $resultcurso = $conexao->query($sqlcurso);

                   while($rowcurso = $resultcurso->fetch_assoc()) {
                     echo "<option value='". $rowcurso["id_classe"]. "'>". $rowcurso["nome"]. "</option>";
                   }
                 
                 ?>
                        </select>
              </div>

              <div class="col-sm-6 d-none">
                <label for="zip" class="form-label">foto de perfil<span class="text-muted">(Optional)</span></label>
                <input type="file" class="form-control" id="zip" placeholder="foto" >
                <div class="invalid-feedback">
                  Zip code required.
                </div>
              </div>
              <div class="col-sm-6">
                  <h4 class="mb-3">Sexo</h4>
                <div class="my-3 d-flex justify-content-around aling-items-center">
                  <div class="form-check">
                    <input id="maculino" name="sexo" value="Masculino" type="radio" class="form-check-input" checked >
                    <label class="form-check-label" for="maculino">Masculino</label>
                  </div>
                  <div class="form-check">
                    <input id="femenino" name="sexo" value="Femenino" type="radio" class="form-check-input" >
                    <label class="form-check-label" for="femenino">Feminino</label>
                  </div>
                </div>
              </div>

            </div>

            <hr class="my-4">

            <button class="w-100 btn btn-primary btn-lg" type="submit" name="cadaluno" id="cadaluno">cadastrar</button>
          </form>

        </div>
      </div>
    </div>
  </div>