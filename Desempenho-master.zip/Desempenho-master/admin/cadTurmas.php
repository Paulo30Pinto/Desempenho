  <!--MODAL CADASTRO TURMAS-->
  <div class="modal fade" id="modalturma" tabindex="-1" aria-labelledby="exampleModalCenteredScrollableTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalCenteredScrollableTitle">Cadastrar Turmas</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="conexao/pdo_cadastro.php" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
            <div class="row g-3">
              <div class="col-sm-6">
                <label for="firstName" class="form-label">Titulo</label>
                <input type="text" class="form-control" id="turmatitulo" name="turmatitulo" placeholder="nome da turma" value="" required>
                <div class="invalid-feedback">
                  não insiriu o seu nome.
                </div>
              </div>

              <div class="col-sm-6">
                <label for="lastName" class="form-label">Sala</label>
                <input type="number" class="form-control" id="sala" name="sala" placeholder="nº da sala" value="" required>
                <div class="invalid-feedback">
                  não insiriu o seu contato.
                </div>
              </div>
              <div class="col-sm-6">
                <label for="username" class="form-label">Classe/Ano</span></label>
                <select class="form-select" aria-label="Default select example" name="classe" id="classe">
                            <option selected>Selecionar Classes</option>
                           
                            <?php
                    
                    $sqlcurso = "SELECT * FROM classes";
                    $resultcurso = $conexao->query($sqlcurso);

                    while($rowcurso = $resultcurso->fetch_assoc()) {
                      echo "<option value='". $rowcurso["id_classe"]. "'>". $rowcurso["nome"]. "</option>";
                    }
                  
                  ?>

                </select>
             
              </div>
              <div class="col-sm-6">
                <label for="address" class="form-label">Curso</label>
                <select class="form-select" aria-label="Default select example" name='curso' id='curso'>
                <option selected >Selecionar Cursos</option>
                  <?php
                    
                    $sqlcurso = "SELECT * FROM cursos";
                    $resultcurso = $conexao->query($sqlcurso);

                    while($rowcurso = $resultcurso->fetch_assoc()) {
                      echo "<option value='$rowcurso[id_curso]'>". $rowcurso["nome"]. "</option>";
                    }
                  
                  ?>
                            
                          
                            
                </select>
               
              </div>

              <div class="col-sm-6">
                <label for="anolectivo" class="form-label">Ano Lectivo </label>
                <input type="number" class="form-control" id="anolectivo" name="anolectivo" placeholder="Ano Lectivo"required>
              </div>
              <div class="col-sm-6">
                  <h4 class="mb-3">Turno</h4>
                <div class="my-3 d-flex justify-content-around aling-items-center">
                  <div class="form-check">
                    <input id="manha" name="turno" type="radio" class="form-check-input" value="Manha" checked required>
                    <label class="form-check-label" for="credit">Manha</label>
                  </div>
                  <div class="form-check">
                    <input id="tarde" value="Tarde" name="turno" type="radio" class="form-check-input" required>
                    <label class="form-check-label" for="debit">Tarde</label>
                  </div>
                  <div class="form-check">
                    <input id="noite" value="Noite" name="turno" type="radio" class="form-check-input" required>
                    <label class="form-check-label" for="paypal">Noite</label>
                  </div>
                </div>
              </div>


            </div>

            <hr class="my-4">

            <button class="w-100 btn btn-primary btn-lg" type="submit" id="btnCadTurma" name="btnCadTurma">cadastrar</button>
          </form>

        </div>
      </div>
    </div>
  </div>